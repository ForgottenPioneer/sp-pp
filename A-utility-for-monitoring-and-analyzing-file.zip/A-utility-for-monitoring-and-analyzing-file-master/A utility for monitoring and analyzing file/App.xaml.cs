﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace A_utility_for_monitoring_and_analyzing_file
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
