﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace redactor_31._10._2024_
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
